jQuery(document).ready(function() {
	jQuery("div[id*='_dropdown-menu-']").addClass('shailan-dropdown');
	jQuery("div[id*='_multi-dropdown-menu-']").addClass('shailan-dropdown');
});